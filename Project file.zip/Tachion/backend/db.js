const { Pool } = require("pg");

const pool = new Pool({
  user: "postgres",        // your PostgreSQL username
  host: "localhost",
  database: "Tachyon",
  password: "madhansmk", // change this
  port: 5432,
});

module.exports = pool;
