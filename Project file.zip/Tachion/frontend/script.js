const API_URL = "http://localhost:5000/api/books";

// Section toggling
function showSection(id) {
  document.querySelectorAll(".section").forEach((s) => s.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");
}

// ✅ CREATE
async function addBook() {
  const title = document.getElementById("addTitle").value.trim();
  const author = document.getElementById("addAuthor").value.trim();
  const quantity = parseInt(document.getElementById("addQuantity").value);
  const price = parseFloat(document.getElementById("addPrice").value);

  if (!title || !author || isNaN(quantity) || isNaN(price)) {
    alert("Please fill all fields correctly!");
    return;
  }

  const res = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title, author, quantity, price }),
  });

  if (res.ok) {
    alert("Book added successfully!");
    clearAddForm();
  } else alert("Failed to add book.");
}

function clearAddForm() {
  document.getElementById("addTitle").value = "";
  document.getElementById("addAuthor").value = "";
  document.getElementById("addQuantity").value = "";
  document.getElementById("addPrice").value = "";
}

// 📖 READ
async function fetchBooks() {
  const res = await fetch(API_URL);
  const books = await res.json();

  const table = document.getElementById("bookTable");
  table.innerHTML = "";

  if (books.length === 0) {
    table.innerHTML = "<tr><td colspan='5'>No books found</td></tr>";
    return;
  }

  books.forEach((book) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${book.id}</td>
      <td>${book.title}</td>
      <td>${book.author}</td>
      <td>${book.quantity}</td>
      <td>${book.price}</td>
    `;
    table.appendChild(row);
  });
}

// ✏️ UPDATE
async function updateBook() {
  const id = document.getElementById("updateId").value;
  const title = document.getElementById("updateTitle").value.trim();
  const author = document.getElementById("updateAuthor").value.trim();
  const quantity = parseInt(document.getElementById("updateQuantity").value);
  const price = parseFloat(document.getElementById("updatePrice").value);

  if (!id || isNaN(id)) return alert("Please enter a valid ID!");

  const res = await fetch(`${API_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title, author, quantity, price }),
  });

  if (res.ok) alert("Book updated successfully!");
  else alert("Failed to update book.");
}

// 🗑️ DELETE
async function deleteBook() {
  const id = document.getElementById("deleteId").value;
  if (!id || isNaN(id)) return alert("Enter a valid ID!");
  if (!confirm("Are you sure you want to delete this book?")) return;

  const res = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
  if (res.ok) alert("Book deleted!");
  else alert("Failed to delete book.");
}
